﻿namespace AMC_Test
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axAxisMediaControl1 = new AxAXISMEDIACONTROLLib.AxAxisMediaControl();
            this.playBtn = new DevExpress.XtraEditors.SimpleButton();
            this.stopBtn = new DevExpress.XtraEditors.SimpleButton();
            this.snapshot_Btn = new DevExpress.XtraEditors.SimpleButton();
            this.startRec_Btn = new DevExpress.XtraEditors.SimpleButton();
            this.stopRec_Btn = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.axAxisMediaControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // axAxisMediaControl1
            // 
            this.axAxisMediaControl1.Enabled = true;
            this.axAxisMediaControl1.Location = new System.Drawing.Point(12, 12);
            this.axAxisMediaControl1.Name = "axAxisMediaControl1";
            this.axAxisMediaControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAxisMediaControl1.OcxState")));
            this.axAxisMediaControl1.Size = new System.Drawing.Size(776, 426);
            this.axAxisMediaControl1.TabIndex = 0;
            // 
            // playBtn
            // 
            this.playBtn.Location = new System.Drawing.Point(12, 444);
            this.playBtn.Name = "playBtn";
            this.playBtn.Size = new System.Drawing.Size(116, 29);
            this.playBtn.TabIndex = 1;
            this.playBtn.Text = "Play";
            this.playBtn.Click += new System.EventHandler(this.playBtn_Click);
            // 
            // stopBtn
            // 
            this.stopBtn.Location = new System.Drawing.Point(134, 444);
            this.stopBtn.Name = "stopBtn";
            this.stopBtn.Size = new System.Drawing.Size(116, 29);
            this.stopBtn.TabIndex = 2;
            this.stopBtn.Text = "Stop";
            this.stopBtn.Click += new System.EventHandler(this.stopBtn_Click);
            // 
            // snapshot_Btn
            // 
            this.snapshot_Btn.Location = new System.Drawing.Point(256, 444);
            this.snapshot_Btn.Name = "snapshot_Btn";
            this.snapshot_Btn.Size = new System.Drawing.Size(116, 29);
            this.snapshot_Btn.TabIndex = 3;
            this.snapshot_Btn.Text = "SnapShot";
            this.snapshot_Btn.Click += new System.EventHandler(this.snapshot_Btn_Click);
            // 
            // startRec_Btn
            // 
            this.startRec_Btn.Location = new System.Drawing.Point(378, 444);
            this.startRec_Btn.Name = "startRec_Btn";
            this.startRec_Btn.Size = new System.Drawing.Size(116, 29);
            this.startRec_Btn.TabIndex = 4;
            this.startRec_Btn.Text = "StartRec";
            this.startRec_Btn.Click += new System.EventHandler(this.startRec_Btn_Click);
            // 
            // stopRec_Btn
            // 
            this.stopRec_Btn.Location = new System.Drawing.Point(500, 444);
            this.stopRec_Btn.Name = "stopRec_Btn";
            this.stopRec_Btn.Size = new System.Drawing.Size(116, 29);
            this.stopRec_Btn.TabIndex = 5;
            this.stopRec_Btn.Text = "StopRec";
            this.stopRec_Btn.Click += new System.EventHandler(this.stopRec_Btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 505);
            this.Controls.Add(this.stopRec_Btn);
            this.Controls.Add(this.startRec_Btn);
            this.Controls.Add(this.snapshot_Btn);
            this.Controls.Add(this.stopBtn);
            this.Controls.Add(this.playBtn);
            this.Controls.Add(this.axAxisMediaControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axAxisMediaControl1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxAXISMEDIACONTROLLib.AxAxisMediaControl axAxisMediaControl1;
        private DevExpress.XtraEditors.SimpleButton playBtn;
        private DevExpress.XtraEditors.SimpleButton stopBtn;
        private DevExpress.XtraEditors.SimpleButton snapshot_Btn;
        private DevExpress.XtraEditors.SimpleButton startRec_Btn;
        private DevExpress.XtraEditors.SimpleButton stopRec_Btn;
    }
}

