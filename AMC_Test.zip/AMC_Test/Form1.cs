﻿using AXISMEDIACONTROLLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AMC_Test
{
    public partial class Form1 : Form
    {

        AxisMediaControl AMC = new AxisMediaControl();

        public Form1()
        {
            InitializeComponent();
        }

        private void playBtn_Click(object sender, EventArgs e)
        {
            AMC.MediaURL = "axrtsp://192.168.75.1/axis-media/media.amp";
            AMC.MediaType = "MJPEG";
            AMC.Play();
        }

        private void stopBtn_Click(object sender, EventArgs e)
        {
            AMC.Stop();
        }

        private void snapshot_Btn_Click(object sender, EventArgs e)
        {
            AMC.SaveCurrentImage(0,"D://SnapShot//axis.jpg");
        }

        private void startRec_Btn_Click(object sender, EventArgs e)
        {
            AMC.StartRecordMedia("D:\\Axis\\test.asf", 8, "0");
        }

        private void stopRec_Btn_Click(object sender, EventArgs e)
        {

            AMC.StopRecordMedia();
        }
    }
}
